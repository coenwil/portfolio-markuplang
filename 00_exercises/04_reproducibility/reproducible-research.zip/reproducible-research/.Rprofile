setHook("rstudio.sessionInit", function(newSession) {
  setwd("docs")
}, action = "append")
