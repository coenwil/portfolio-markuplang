# my-reproducible manuscript

<!-- badges: start -->
<!-- badges: end -->

NOTE: on my linux machine I had to add a .Rprofile file to point the knitting process of Quarto to the right directory within the R project. If you get any errors running the file, try deleting it. Furthermore, my way of writing the relative paths in the R scripts may also be a little different (for example is read.csv()). Please keep that in mind when trying to knit the file or run the code. I did not expect to run into these errors, and I do not have the ability to check them on someone elses machine.

The goal of my-reproducible-manuscript is to complete a homework assignment for Markup Languages and Reproducible Programming in Statistics. It is a second year course in my Methods and Statistics master.

My name is Coen and my student number is 1476092. It is 10-11-2026 09:48.

